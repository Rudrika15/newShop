
<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php if(session()->has('success')): ?>
            <script>
                Swal.fire(
                    'Success!',
                    '<?php echo e(session('success')); ?>',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row p-3">
                            <div class="col-lg-6">
                                <h2>
                                    Reports

                                </h2>
                            </div>

                        </div>
                        <!-- SKU List Table -->

                        <?php if(count($userReports) !== 0): ?>
                            <div class="">
                                <h3>User Reports</h3>
                                <div class="pt-2">
                                    <form action="<?php echo e(route('reports.index')); ?>" method="get">
                                        <label for="">Find User</label>
                                        <div class="input-group mb-3">
                                            <input type="date" name="from" class="form-control shadow-none"
                                                id="">
                                            <input type="date" name="to" class="form-control shadow-none"
                                                id="">
                                            <button class="btn btn-primary shadow-none" type="submit">Search</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-borderless">
                                        <thead>
                                            <tr>
                                                <th scope="col">Name</th>
                                                <th scope="col">Email</th>
                                                <th scope="col">Contact</th>
                                                <th scope="col">Total Orders</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($userReports): ?>
                                                <?php $__currentLoopData = $userReports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($user->users->name); ?></td>
                                                        <td><?php echo e($user->users->email); ?></td>
                                                        <td><?php echo e($user->users->contact); ?></td>
                                                        <td><?php echo e($user->total_orders); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>

                            </div>
                        <?php endif; ?>
                       
                    </div>

                </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/reports/index-user.blade.php ENDPATH**/ ?>