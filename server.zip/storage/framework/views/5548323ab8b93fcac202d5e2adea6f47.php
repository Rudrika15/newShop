<?php $__env->startSection('content'); ?>
    <div class="conatinter">

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="d-flex justify-content-between  mb-3">
                        <div class="p-2 fs-4"> Slider Create</div>

                        <div class="p-2 ">
                            <a href="<?php echo e(route('slider.index')); ?>" class="btn btn-primary">Back</a>
                        </div>

                    </div>
                    <div class="card-body py-3">
                        <form method="POST" action="<?php echo e(route('slider.store')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <div class="row mb-3">
                                <div class="row mb-3">
                                    <label for="sliderImage" class="form-label">Slider Image</label>
                                    <input class="form-control mb-2" type="file" name="sliderImage" id="sliderImage">
                                    <span class="text-danger">
                                        <?php $__errorArgs = ['sliderImage'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <?php echo e($message); ?>

                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </span>
                                </div>

                                <div class="row mb-3">
                                    <label for="check">
                                        <input type="checkbox" name="isNavigate" class="form-check-input" id="check"> Is Navigate
                                    </label>
                                </div>


                                <div id="navDiv" class="d-none">

                                    <label for="sliderName" class="col-form-label ">Slider Name</label>

                                    <div class="col-md-12">
                                        <select id="sliderName"
                                            class="form-control <?php $__errorArgs = ['sliderName'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="catalogId">
                                            <option disabled selected>Select</option>
                                            <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($catalog->id); ?>"><?php echo e($catalog->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <input type="hidden" name="title" id="title"/>
                                    </div>
                                </div>
                            </div>

                            <div class="row d-flex justify-content-center">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('Submit')); ?>

                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        document.getElementById('sliderName').addEventListener('change', function() {
            const selectedOption = this.options[this.selectedIndex].text;
            document.getElementById('title').value = selectedOption;
        });
    });
</script>
<script>
    $(document).ready(function() {
        $('#check').on('change', function() {
            if ($(this).is(':checked')) {
                $('#navDiv').removeClass('d-none');
            } else {
                $('#navDiv').addClass('d-none');
            }
        })
    });
</script>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/slider/create.blade.php ENDPATH**/ ?>