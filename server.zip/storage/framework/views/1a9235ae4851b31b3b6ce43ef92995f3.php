<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-lg-10 ">

        </div>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <div class="d-flex justify-content-between  mb-3">
                            <div class="p-2 fs-4"> Category Create</div>

                            <div class="p-2 ">
                                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary">Back</a>
                            </div>

                        </div>

                    </div>
                    <div class="card-body ">
                        <form method="POST" action="<?php echo e(route('category.store')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group mb-3">
                                <label for="categoryname" class="mt-2">Category Name</label>
                                <input id="categoryname" type="text"
                                    class="form-control <?php $__errorArgs = ['categoryname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> mt-2"
                                    name="categoryname" value="<?php echo e(old('categoryname')); ?>">
                                <?php $__errorArgs = ['categoryname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="form-group mb-3">
                                <input type="checkbox" id="is_parent" name="is_parent" value="1"
                                    <?php echo e(old('is_parent', true) ? 'checked' : ''); ?>>
                                <label for="is_parent">Is Parent</label>
                            </div>
                            <div class="form-group mb-4">
                                <label for="parent">Parent Category</label>
                                <select class="form-control mt-2" id="parent" name="parent"
                                    <?php echo e(old('is_parent', true) ? 'disabled' : ''); ?>>
                                    <option value="">Select Parent Category</option>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($parent->id); ?>"
                                            <?php echo e(old('parent') == $parent->id ? 'selected' : ''); ?>>
                                            <?php echo e($parent->categoryname); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php $__errorArgs = ['parent'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                            <div class="row d-flex justify-content-end my-3">
                                <div class="col-lg-6 d-flex justify-content-end">
                                    <span style="float:right;"><button type="submit"
                                            class="btn btn-primary">Submit</button>
                                    </span>
                                </div>
                                <div class="col-lg-6 d-flex justify-content-start">
                                    <span style="float:right;"><a href="<?php echo e(route('category.index')); ?>"
                                            class="btn btn-danger ">Exit</a>
                                    </span>
                                </div>

                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        document.getElementById('is_parent').addEventListener('change', function() {
            document.getElementById('parent').disabled = this.checked;
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/category/create.blade.php ENDPATH**/ ?>