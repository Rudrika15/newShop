<?php $__env->startSection('title', 'Products'); ?>

<?php $__env->startSection('content'); ?>
    <nav aria-label="breadcrumb" style="background-color: #1582d4;height: 100px; padding-top: 35px ;padding-left:40%">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>" class="text-light">Home</a></li>
            <li class="breadcrumb-item " class="text-light" aria-current="page">Product</li>
        </ol>
    </nav>
    <div class="container">
        <div class="row py-5">
            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">

                    <div class="card">
                        <img src="<?php echo e(asset('images/catalog/' . $data->main_image)); ?>" class="card-img-top" alt="...">
                        <div class="card-body">
                            <h5 class="card-title"><?php echo e(Str::ucfirst($data->title)); ?></h5>
                            <a href="<?php echo e(route('product.detail', $data->id)); ?>" class="btn btn-primary">View more</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/visitor/product/product.blade.php ENDPATH**/ ?>