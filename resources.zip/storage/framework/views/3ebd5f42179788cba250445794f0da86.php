<?php $__env->startSection('title', 'Home'); ?>
<?php $__env->startSection('content'); ?>
    <div id="carouselExampleDark" class="carousel carousel-dark slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="0" class="active" aria-current="true"
                aria-label="Slide 1"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="1" aria-label="Slide 2"></button>
            <button type="button" data-bs-target="#carouselExampleDark" data-bs-slide-to="2" aria-label="Slide 3"></button>
        </div>
        <div class="carousel-inner">
            <div class="carousel-item active" data-bs-interval="10000">
                <img src="<?php echo e(asset('images/product/stefan-stefancik--g7axSVst6Y-unsplash.jpg')); ?>" class="img-fluid"
                    alt="">
            </div>
            <div class="carousel-item" data-bs-interval="2000">
                <img src="<?php echo e(asset('images/product/v2osk-1Z2niiBPg5A-unsplash.jpg')); ?>" class="img-fluid" alt="">
            </div>
            <div class="carousel-item">
                <img src="<?php echo e(asset('images/product/stefan-stefancik--g7axSVst6Y-unsplash.jpg')); ?>" class="img-fluid"
                    alt="">
            </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleDark" data-bs-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="visually-hidden">Next</span>
        </button>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('visitor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/visitor/home/home.blade.php ENDPATH**/ ?>