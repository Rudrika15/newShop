
<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php if(session()->has('success')): ?>
            <script>
                Swal.fire(
                    'Success!',
                    '<?php echo e(session('success')); ?>',
                    'success'
                );
            </script>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row p-3">

                        </div>
                        <!-- SKU List Table -->


                        <!-- SKU List Table -->

                        <?php if(count($catalogReport) !== 0): ?>
                            <div class="">
                                <h3>Catelog Reports</h3>
                                <div class="pt-2">
                                    <form action="<?php echo e(route('reports.index')); ?>" method="get">
                                        <label for="">Find catalog</label>
                                        <div class="input-group mb-3">
                                            <input type="date" name="fromC" class="form-control shadow-none"
                                                id="">
                                            <input type="date" name="toC" class="form-control shadow-none"
                                                id="">
                                            <button class="btn btn-primary shadow-none" type="submit">Search</button>
                                        </div>
                                    </form>
                                </div>
                                <div class="table-responsive">
                                    <table class="table table-borderless">
                                        <thead>
                                            <tr>
                                                <th scope="col">Image</th>
                                                <th scope="col">Product Name</th>
                                                <th scope="col">Product Color</th>
                                                <th scope="col">Product Catelog</th>
                                                <th scope="col">Total Orders</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php if($catalogReport): ?>
                                                <?php $__currentLoopData = $catalogReport; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catelog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><img src="<?php echo e(asset('images/catalog')); ?>/<?php echo e($catelog->product->catalog->main_image); ?>"
                                                                width="80" alt=""></td>
                                                        <td>
                                                            <?php echo e($catelog->product->slug); ?>

                                                            <br />
                                                            <?php echo e($catelog->product->sku); ?>

                                                        </td>
                                                        <td><?php echo e($catelog->product->color); ?></td>
                                                        <td><?php echo e($catelog->product->catalog->title); ?></td>
                                                        <td><?php echo e($catelog->total_sales); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php endif; ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>

                </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/reports/index-catalog.blade.php ENDPATH**/ ?>