<?php $__env->startSection('content'); ?>
    <section class="section">
        
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row p-3">
                            <div class="col-lg-6">
                                <h4 class="pt-2">
                                    <?php if(count($categories) > 0): ?>
                                        Category List
                                    <?php else: ?>
                                        There are no data to show
                                    <?php endif; ?>
                                </h4>
                            </div>
                            <div class="col-lg-6 d-flex justify-content-end align-items-center">
                                <span style="float:right;"><a href="<?php echo e(route('category.trash')); ?>"
                                        class="btn btn-warning">Go To Trash</a>
                                </span>
                                <span style="float:right;"><a href="<?php echo e(route('category.create')); ?>"
                                        class="btn btn-primary ms-2">Add
                                        Category</a>
                                </span>
                            </div>
                        </div>
                        <!-- SKU List Table -->

                        <?php if(count($categories) !== 0): ?>
                            <table id="sku-table" class="table table-bordered text-center">
                                <thead>
                                    <tr>
                                        <th>Category Name</th>
                                        
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($category->categoryname); ?> 
                                                <?php if($category->is_parent && $category->children->isNotEmpty()): ?>
                                                    <b> => </b>
                                                    <?php $__currentLoopData = $category->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $child): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($child->categoryname); ?>

                                                        <?php if(!$loop->last): ?> <b> => </b> <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php endif; ?>
                                                
                                            </td>
                                            
                                            <td>
                                                <div class="d-flex gap-2 justify-content-center">
                                                    <div>
                                                        <a href="<?php echo e(route('category.edit', $category->id)); ?>"
                                                            class="btn btn-primary btn-sm shadow-none mb-2 ">Edit</a>
                                                    </div>
                                                    <div>
                                                        <button class="delete-user btn btn-danger btn-sm shadow-none"
                                                            data-id="<?php echo e($category->id); ?>">Delete</button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        <!-- Pagination Links -->
        <?php echo $categories->withQueryString()->links('pagination::bootstrap-5'); ?>

        <script>
            const deleteButtons = document.querySelectorAll('.delete-user');

            deleteButtons.forEach(button => {
                button.addEventListener('click', (e) => {
                    e.preventDefault();
                    const userId = e.target.getAttribute('data-id');

                    Swal.fire({
                        title: 'Are you sure?',
                        text: 'You won\'t be able to revert this!',
                        icon: 'warning', //question , error , warning , success , info

                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Yes, delete it!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Redirect to a route that handles user deletion
                            window.location.href = `/category/delete/${userId}`;
                        }
                    });
                });
            });
        </script>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/category/index.blade.php ENDPATH**/ ?>