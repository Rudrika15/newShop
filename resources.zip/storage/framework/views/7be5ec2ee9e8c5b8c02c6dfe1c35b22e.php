<?php $__env->startSection('content'); ?>
    <div class="container">
        <?php if($message = Session::get('success')): ?>
            <div class="col-lg-6 alert alert-success" id="successMessage">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="row p-2">
                <div class="col-lg-6">
                    <h4 class="pt-2">
                        <?php if(count($catalogs) > 0): ?>
                            Product Trash Data
                        <?php else: ?>
                            There are no data to show
                        <?php endif; ?>
                    </h4>
                </div>
                <div class="col-lg-6 d-flex justify-content-end align-items-center">
                    <span style="float:right;"><a href="<?php echo e(route('product.index')); ?>" class="btn btn-primary shadow-none">Go
                            Back</a></span>
                </div>
            </div>
            <?php if(count($catalogs) !== 0): ?>
                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead class="table-secondary">
                            <tr class="text-center">
                                <th>Sr. no</th>
                                <th>Catalog Name</th>
                                <th>Main Image</th>
                                <th>Product</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $i = 1;
                            ?>
                            <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="text-center">
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($catalog->title); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('images/catalog/' . $catalog->main_image)); ?>" width="50"
                                            height="50">
                                    </td>

                                    <td>
                                        <div class="d-flex gap-2 justify-content-center flex-nowrap">
                                            <?php $__currentLoopData = $catalog->products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <div>
                                                    <a href="<?php echo e(route('product.view', $product->id)); ?>"
                                                        class="btn btn-primary btn-sm shadow-none">
                                                        <?php echo e($product->slug); ?>

                                                    </a>
                                                </div>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </td>
                                    <td>
                                        <div class="d-flex gap-2 justify-content-center">
                                            <div>
                                                <button class="product-restore btn btn-primary btn-sm shadow-none"
                                                    data-id="<?php echo e($catalog->id); ?>">Restore</button>
                                            </div>
                                            <div>
                                                <div>
                                                    <button class="delete-user btn btn-danger btn-sm shadow-none"
                                                        data-id="<?php echo e($catalog->id); ?>">Delete</button>
                                                </div>
                                            </div>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <?php echo $catalogs->withQueryString()->links('pagination::bootstrap-5'); ?>


    <script>
        const deleteButtons = document.querySelectorAll('.delete-user');

        deleteButtons.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const userId = e.target.getAttribute('data-id');

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You won\'t be able to revert this!',
                    icon: 'warning', //question , error , warning , success , info

                    showCancelButton: true,
                    confirmButtonColor: '#d33',
                    cancelButtonColor: '#3085d6',
                    confirmButtonText: 'Yes, permanently delete  it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Redirect to a route that handles user deletion
                        window.location.href = `/catalog/force-delete/${userId}`;
                        Swal.fire('Deleted!', 'Deleted Successfully.', 'success');
                    }
                });
            });
        });
    </script>


    <script>
        const productRestore = document.querySelectorAll('.product-restore');

        productRestore.forEach(button => {
            button.addEventListener('click', (e) => {
                e.preventDefault();
                const userId = e.target.getAttribute('data-id');

                Swal.fire({
                    title: 'Are you sure?',
                    text: 'You want to restore this product ?',
                    icon: 'question', //question , error , warning , success , info

                    showCancelButton: true,
                    confirmButtonColor: '#3085d6',
                    cancelButtonColor: '#d33',
                    confirmButtonText: 'Yes, restore it!'
                }).then((result) => {
                    if (result.isConfirmed) {
                        // Redirect to a route that handles user deletion
                        window.location.href = `/catalog/restore/${userId}`;
                        Swal.fire('Restored!', 'Product Restored Successfully.', 'success');
                    }
                });
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/product/trash.blade.php ENDPATH**/ ?>