<?php $__env->startSection('content'); ?>
    <section class="section">
        <?php if($message = Session::get('success')): ?>
            <div class="col-lg-6 alert alert-success" id="successMessage">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="row">
            <div class="col-lg-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row p-3">
                            <div class="col-lg-6">
                                <h4 class="pt-2">
                                    <?php if(count($orders) > 0): ?>
                                        REPOERT LIST
                                    <?php else: ?>
                                        There are no data
                                    <?php endif; ?>
                                </h4>
                            </div>
                            
                        </div>
                        <!-- SKU List Table -->

                        <?php if(count($orders) !== 0): ?>
                            <table id="sku-table" class="table table-bordered text-center">
                                <thead class="table-secondary">
                                    <tr>
                                        <th>Address</th>
                                        <th>Pincode</th>
                                        <th>Sku</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($order->user_id); ?></td>
                                            <td><?php echo e($order->product_id); ?></td>
                                            <td><?php echo e($order->price); ?></td>
                                            
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
        
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Shiv\newShop\newShop\resources\views/order/index.blade.php ENDPATH**/ ?>