<?php $__env->startSection('content'); ?>
    
    <div class="container">
        <?php if($message = Session::get('success')): ?>
            <div class="col-lg-6 alert alert-success" id="successMessage">
                <p><?php echo e($message); ?></p>
            </div>
        <?php endif; ?>
        <div class="row justify-content-center">
            <div class="col-md-12">
                <h2 class="text-center">Hello, Admin</h2>
                <!-- ======= Dashboard ======= -->
                <section id="dashboard" class="dashboard">

                    <div class="row">
                        <!-- Out-of-Stock Products -->
                        <div class="col-lg-12">
                            <div class="card-body mb-2">
                                <h5 class="card-title">Update stock</h5>
                                <table class="table table-bordered text-center">
                                    <thead>
                                        <tr>
                                            <th>Catalog Name</th>
                                            <th>Product Name</th>
                                            <th>Quantity</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $catalogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td><?php echo e($catalog->catalog->title); ?></td>
                                                <td>
                                                    <?php echo e($catalog->slug); ?>

                                                    <br>
                                                    <?php echo e($catalog->sku); ?>

                                                </td>
                                    
                                                <td>
                                                    <?php if($catalog->getStoke): ?> 
                                                        <?php echo e($catalog->getStoke->quantity ?? 'N/A'); ?> 
                                                    <?php else: ?>
                                                        N/A
                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <a href="<?php echo e(route('product.edit', $catalog->id)); ?>" class="btn btn-primary">Edit</a>
                                                </td>

                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                    
                                </table>
                            </div>
                            <?php echo $catalogs->withQueryString()->links('pagination::bootstrap-5'); ?>

                        </div>
                    </div>

                    <div class="row">
                        <!-- Recent Orders -->
                        <div class="col-lg-12">
                            <div class="card">
                                <div class="card-body">
                                    <div class="d-flex justify-content-between">

                                        <h5 class="my-3">Recent Orders</h5>
                                        <div>
                                            <a href="<?php echo e(route('admin.home')); ?>" class="btn btn-primary my-3 ">Refresh</a>
                                        </div>
                                    </div>
                                    <?php if(count($orders) !== 0): ?>
                                        <table id="slider-table" class="table table-bordered text-center">
                                            <thead class="">
                                                <tr>
                                                    <th>No</th>
                                                    <th>User Name</th>
                                                    <th>Address</th>
                                                    <th>Payment ID</th>
                                                    <th>Product Name</th>
                                                    <th>Quantity</th>
                                                    <th>Order Status</th>
                                                    <th>Price</th>
                                                    <th>Total Amount</th>
                                                    <th>Order Date</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td><?php echo e($loop->iteration); ?></td>
                                                        <td><?php echo e($order->order->users->name ?? '-'); ?>

                                                            <br />
                                                            <?php echo e($order->order->users->contact ?? '-'); ?>

                                                        </td>
                                                        <td><?php echo e($order->customer_address ?? '-'); ?></td>
                                                        <td><?php echo e($order->order->payment_id ?? '-'); ?></td>
                                                        <td><?php echo e($order->product->slug ?? '-'); ?>

                                                            <br />
                                                            <?php echo e($order->product->sku ?? '-'); ?>

                                                        </td>
                                                        <td><?php echo e($order->quantity ?? '-'); ?></td>
                                                        <td>
                                                            <?php echo e($order->orderStatus ?? '-'); ?>

                                                        </td>
                                                        
                                                        <td><?php echo e($order->price ?? '-'); ?></td>
                                                        <td><?php echo e($order->order->amount ?? '-'); ?></td>
                                                        <td>
                                                            <?php
                                                                $date = date('d-M-Y', strtotime($order->created_at));
                                                            ?>
                                                            <?php echo e($date ?? '-'); ?>

                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </tbody>
                                        </table>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>



                </section>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\flipcode\laravel\MSOnline(UmangBhai)\resources\views/adminHome.blade.php ENDPATH**/ ?>